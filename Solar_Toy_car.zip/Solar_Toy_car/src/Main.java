public class Main {
    public static void main(String[] args) {

        SolarToyCar myCar = new SolarToyCar();
        System.out.println(myCar.getBattery());
        myCar.turn(Direction.RIGHT, 55);
        System.out.println(myCar.getBattery());
        myCar.foweward(60.0);
        System.out.println(myCar.getBattery());
        myCar.turnWithSolarEnergy(10.0);
        System.out.println(myCar.getBattery());
        myCar.moveWithSolarEnergy(12.0);
        System.out.println(myCar.getBattery());
        myCar.chargeBattery();
        System.out.println(myCar.getBattery());

    }
}