public class SolarToyCar extends ToyCar implements SolarPanel{

    public void chargeBattery() {
        System.out.println("Charger battery with" + numPanels + "solar Panels" );
        this.batteryLevel = fullBattery;
    }
    public void moveWithSolarEnergy(double distance){
        System.out.println("move for " + distance + "meters " + "without using battery power");
    }

    public void turnWithSolarEnergy(double angle){
        System.out.println("Turn for " + angle + "degrees " + "without using battery power");
    }

}
